#' Collection of helpfull functions
#'
#' Collection of helpfull functions
#'
#' @name myUtils-package
#' @aliases myUtils-package myUtils
#' @docType package
#' @import dplyr shiny ggplot2
#' @importFrom magrittr %>%
#' @importFrom rlang .data
NULL
