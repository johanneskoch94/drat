library(testthat)
library(myUtils)

test_check("myUtils")

